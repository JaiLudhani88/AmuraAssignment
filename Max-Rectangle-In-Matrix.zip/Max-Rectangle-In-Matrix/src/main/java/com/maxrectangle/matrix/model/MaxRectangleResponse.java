package com.maxrectangle.matrix.model;

public class MaxRectangleResponse {
    private Integer x;
    private Integer y;
    private Integer length;
    private Integer height;

    public MaxRectangleResponse(Integer x, Integer y, Integer length, Integer height) {
        this.x = x;
        this.y = y;
        this.length = length;
        this.height = height;
    }

    public Integer getX() {
        return x;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer y) {
        this.y = y;
    }

    public Integer getLength() {
        return length;
    }

    public void setLength(Integer length) {
        this.length = length;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

	@Override
	public String toString() {
		return "MaxRectangleResponse [x=" + x + ", y=" + y + ", length=" + length + ", height=" + height + "]";
	}
    
    
}
