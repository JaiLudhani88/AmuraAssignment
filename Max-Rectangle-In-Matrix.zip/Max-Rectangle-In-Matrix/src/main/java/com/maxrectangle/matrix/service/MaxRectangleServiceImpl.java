package com.maxrectangle.matrix.service;

import com.maxrectangle.matrix.model.MaxRectangleResponse;
import org.springframework.stereotype.Service;

@Service
public class MaxRectangleServiceImpl implements MaxRectangleService {

    @Override
    public MaxRectangleResponse maximalRectangle(int[][] matrix) {
        if (matrix == null || matrix.length == 0)
            return null;
        int row = matrix.length;
        int col = matrix[0].length;
        int max = 0;

        int[][] dp = new int[row][col];
        for (int i = 0; i < row; i++) {
            if (matrix[i][0] == 1)
                dp[i][0] = 1;
        }

        for (int i = 0; i < row; i++) {
            for (int j = 1; j < col; j++) {
                if (matrix[i][j] == 1)
                    dp[i][j] = dp[i][j - 1] + 1;
            }
        }

        int x =-1;
        int y = -1;
        int length =0;
        int height =0;

        for (int j = 0; j < col; j++) {
            for (int i = 0; i < row; i++) {
                if (matrix[i][j] == 0) {
                    continue;
                }
                int min = dp[i][j];
                for (int k = i; k >= 0 && matrix[i][j] == 1; k--) {
                    if (min > dp[k][j])
                        min = dp[k][j];

                    if (min * (i - k + 1) > max)
                    {
                        max = min * (i - k + 1);
                        x = k;
                        y = j;
                        length = min;
                        height = max/min;

                    }

                }
            }
        }
        for(int a = y ; a>=0; a-- )
        {
            if(matrix[x][a] >=1)
            {
                y = a;
                continue;
            }
            else
            {
                break;
            }
        }
       //System.out.println("x: " + x + " y: "+ y +  " length:" + length + " height:" + height);
        return new MaxRectangleResponse(x,y,length,height);
    }

}
