package com.maxrectangle.matrix.service;

import com.maxrectangle.matrix.model.MaxRectangleResponse;
import org.springframework.stereotype.Service;

@Service
public interface MaxRectangleService {
    public MaxRectangleResponse maximalRectangle(int[][] matrix);
}
