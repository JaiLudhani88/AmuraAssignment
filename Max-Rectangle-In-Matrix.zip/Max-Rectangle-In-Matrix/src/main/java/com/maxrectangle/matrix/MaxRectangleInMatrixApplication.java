package com.maxrectangle.matrix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaxRectangleInMatrixApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaxRectangleInMatrixApplication.class, args);
	}

}
