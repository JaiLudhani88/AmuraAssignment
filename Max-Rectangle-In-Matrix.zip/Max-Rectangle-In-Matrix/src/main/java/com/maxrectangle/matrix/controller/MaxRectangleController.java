package com.maxrectangle.matrix.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.maxrectangle.matrix.model.MaxRectangleResponse;
import com.maxrectangle.matrix.service.MaxRectangleService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/api/v1")
@Api(value = "Max Rectangle in Matrix System", description = "Max Rectangle in Matrix System That should return x and y coordinate and length and width ")
public class MaxRectangleController {

    @Autowired
    private MaxRectangleService maxRectangleService;

    @ApiOperation(value = "Find Maximum sub rectangle from given 2D matrix")
    @PostMapping(value="/maxRectangle")
    public MaxRectangleResponse maxRectangle(
            @ApiParam(value = "2D matrix", required = true)
            @Valid @RequestBody int[][] matrix) {
        return  maxRectangleService.maximalRectangle(matrix);
    }
}


