package com.maxrectangle.matrix;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MaxRectangleApplicationTests {

	@Test
	public void contextLoads()  {
		MaxRectangleInMatrixApplicationTests test = new MaxRectangleInMatrixApplicationTests();
		
		try {
			test.testMaxSizedSubRectangle();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}