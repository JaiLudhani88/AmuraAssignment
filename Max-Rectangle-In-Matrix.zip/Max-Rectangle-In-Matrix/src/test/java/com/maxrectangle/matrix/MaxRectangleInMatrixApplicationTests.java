package com.maxrectangle.matrix;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.maxrectangle.matrix.controller.MaxRectangleController;
import com.maxrectangle.matrix.service.MaxRectangleService;

@RunWith(SpringRunner.class)
@SpringBootTest
@WebMvcTest(value = MaxRectangleController.class, secure = false)
public class MaxRectangleInMatrixApplicationTests {
	
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private MaxRectangleService maxRectangleService;

	String exampleResultJson = "{\"x\" : 1, \"y\": 1, \"length\": 4, \"height\": 2}";
    
	@Test
	public void testMaxSizedSubRectangle() throws Exception {
		

		
		int mockArr[][] = {
		           	{1, 0, 0, 0, 0, 1},
		        	{0, 1, 1, 1, 1, 0},
		        	{0, 1, 1, 1, 1, 0},
		        	{0, 0, 0, 1, 0, 0}
		};
		
		
		mockMvc.perform(MockMvcRequestBuilders.post("http://localhost:8080/api/v1/maxRectangle")
				.contentType(MediaType.APPLICATION_JSON)
				.content(exampleResultJson)
				.accept(MediaType.APPLICATION_JSON));

		Mockito.when(
				maxRectangleService.maximalRectangle(mockArr));

	
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("http://localhost:8080/api/v1/maxRectangle")
				.accept(MediaType.APPLICATION_JSON).content(exampleResultJson)
				.contentType(MediaType.APPLICATION_JSON);
		

	

	}

}
